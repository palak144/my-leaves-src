// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,


  firebase: {
    apiKey: "AIzaSyAwju9E7Eo-8doT8B5BXtH6tIEb8Wcx0_c",
    authDomain: "leave-management-18e03.firebaseapp.com",
    databaseURL: "https://leave-management-18e03.firebaseio.com",
    projectId: "leave-management-18e03",
    storageBucket: "leave-management-18e03.appspot.com",
    messagingSenderId: "214958831031",
    appId: "1:214958831031:web:52cfcc769c62608c672432",
    vapidKey: "BBcThxhsSs92sKboUXJZJMofFyAncnz1VJ73u6ZoCR8xPBlVTqhYftm56Y-2KlBILVcaFmSw-RwRGd_kVS3dYb4"
  }/*Copied from FCM login by Bhushan : 13-01-2020*/
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.

