export const environment = {
  production: true,

  firebase: {
    apiKey: "AIzaSyAwju9E7Eo-8doT8B5BXtH6tIEb8Wcx0_c",
    authDomain: "leave-management-18e03.firebaseapp.com",
    databaseURL: "https://leave-management-18e03.firebaseio.com",
    projectId: "leave-management-18e03",
    storageBucket: "leave-management-18e03.appspot.com",
    messagingSenderId: "214958831031",
    appId: "1:214958831031:web:52cfcc769c62608c672432",
    vapidKey: "BBcThxhsSs92sKboUXJZJMofFyAncnz1VJ73u6ZoCR8xPBlVTqhYftm56Y-2KlBILVcaFmSw-RwRGd_kVS3dYb4"
  }/*Copied from FCM login by Bhushan : 13-01-2020*/
};
