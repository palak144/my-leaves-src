import { TestBed } from '@angular/core/testing';

import { FaqQuestionsService } from './faq-questions.service';

describe('FaqQuestionsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FaqQuestionsService = TestBed.get(FaqQuestionsService);
    expect(service).toBeTruthy();
  });
});
