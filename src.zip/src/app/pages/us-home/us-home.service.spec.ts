import { TestBed } from '@angular/core/testing';

import { UsHomeService } from './us-home.service';

describe('UsHomeService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UsHomeService = TestBed.get(UsHomeService);
    expect(service).toBeTruthy();
  });
});
