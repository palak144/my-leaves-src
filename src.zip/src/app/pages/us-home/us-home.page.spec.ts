import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UsHomePage } from './us-home.page';

describe('UsHomePage', () => {
  let component: UsHomePage;
  let fixture: ComponentFixture<UsHomePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UsHomePage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UsHomePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
