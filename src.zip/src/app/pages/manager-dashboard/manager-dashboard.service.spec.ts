import { TestBed } from '@angular/core/testing';

import { ManagerDashboardService } from './manager-dashboard.service';

describe('ManagerDashboardService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ManagerDashboardService = TestBed.get(ManagerDashboardService);
    expect(service).toBeTruthy();
  });
});
