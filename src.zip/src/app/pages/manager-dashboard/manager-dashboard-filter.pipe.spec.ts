import { ManagerDashboardFilterPipe } from './manager-dashboard-filter.pipe';

describe('ManagerDashboardFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new ManagerDashboardFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
