import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SaHomePage } from './sa-home.page';

describe('SaHomePage', () => {
  let component: SaHomePage;
  let fixture: ComponentFixture<SaHomePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SaHomePage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SaHomePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
