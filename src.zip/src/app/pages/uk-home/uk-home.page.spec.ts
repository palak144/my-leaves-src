import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UkHomePage } from './uk-home.page';

describe('UkHomePage', () => {
  let component: UkHomePage;
  let fixture: ComponentFixture<UkHomePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UkHomePage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UkHomePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
